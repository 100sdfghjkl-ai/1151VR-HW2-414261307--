using UnityEngine;
using System.Collections; 

public class PlayerPath : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 7f;
    private Rigidbody2D rb;
    private bool isGrounded = true;

    public Vector3[] checkpoints = new Vector3[2];

    private Collider2D playerCollider;
    private GameObject currentGround;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerCollider = GetComponent<Collider2D>(); 

        checkpoints[0] = transform.position;
    }

    void Update()
    {
        float moveInput = Input.GetAxis("Horizontal");
        rb.linearVelocity = new Vector2(moveInput * moveSpeed, rb.linearVelocity.y);

        if (Input.GetKeyDown(KeyCode.W) && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            isGrounded = false;
        }

        if (Input.GetKeyDown(KeyCode.S) && isGrounded && currentGround != null)
        {
            StartCoroutine(DropThroughGround());
        }
    }

    IEnumerator DropThroughGround()
    {
        Collider2D groundCollider = currentGround.GetComponent<Collider2D>();

        Physics2D.IgnoreCollision(playerCollider, groundCollider, true);

        yield return new WaitForSeconds(0.5f);

        Physics2D.IgnoreCollision(playerCollider, groundCollider, false);
    }


    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;

            currentGround = collision.gameObject;
        }
    }


    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            // 清空紀錄，代表目前沒有踩在地板上
            currentGround = null;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Finish"))
        {
            Debug.Log("抵達終點！遊戲結束。");
            checkpoints[1] = other.transform.position;

            Time.timeScale = 0f;

        }
    }
}